/* ---------- SEARCH ---------- */
const F={price:10000,rating:0,types:[],amen:[],bf:false,fc:false,sort:'rec'};
function search(){const c=crit();const types=[...new Set(HOTELS.map(h=>h.propertyType))],am=[...new Set(HOTELS.flatMap(h=>h.amenities))];
app.innerHTML=`<div class="wrap sec"><div class="summ"><b>${c.city||'All cities'}</b> · ${fdate(c.checkIn)} → ${fdate(c.checkOut)} · ${c.guests} guest(s) · ${c.rooms} room(s) <a href="index.html">Modify</a></div>
<div class="split"><aside class="filters"><h3>Filters</h3><label>Max price: <b id="pv">${fmt(F.price)}</b><input type="range" id="fp" min="2000" max="10000" step="100" value="${F.price}"></label>
<label>Min rating<select id="fr">${[0,3.5,4,4.5].map(r=>`<option value="${r}" ${F.rating==r?'selected':''}>${r?r+'+':'Any'}</option>`).join('')}</select></label>
<h4>Property type</h4>${types.map(t=>`<label class="ck"><input type="checkbox" data-t="${t}" ${F.types.includes(t)?'checked':''}>${t}</label>`).join('')}
<h4>Amenities</h4>${am.map(t=>`<label class="ck"><input type="checkbox" data-a="${t}" ${F.amen.includes(t)?'checked':''}>${t}</label>`).join('')}
<label class="ck"><input type="checkbox" id="fb" ${F.bf?'checked':''}>Breakfast included</label><label class="ck"><input type="checkbox" id="ff" ${F.fc?'checked':''}>Free cancellation</label><button class="btn ghost" id="rs">Reset</button></aside>
<div><div class="row"><h2 id="cnt"></h2><select id="so">${[['rec','Recommended'],['pa','Price low to high'],['pd','Price high to low'],['rt','Highest rated'],['di','Distance']].map(o=>`<option value="${o[0]}" ${F.sort==o[0]?'selected':''}>${o[1]}</option>`).join('')}</select></div><div id="res" class="list"></div></div></div></div>`;
const draw=()=>{let l=HOTELS.filter(h=>(!c.city||h.city.toLowerCase().includes(c.city.toLowerCase()))&&h.price<=F.price&&h.rating>=F.rating&&(!F.types.length||F.types.includes(h.propertyType))&&F.amen.every(a=>h.amenities.includes(a))&&(!F.bf||h.breakfastAvailable)&&(!F.fc||h.freeCancel));
 const dk=h=>parseFloat(h.distance)||0;const S={rec:(a,b)=>b.rating*Math.log(b.reviewCount)-a.rating*Math.log(a.reviewCount),pa:(a,b)=>a.price-b.price,pd:(a,b)=>b.price-a.price,rt:(a,b)=>b.rating-a.rating,di:(a,b)=>dk(a)-dk(b)};l.sort(S[F.sort]);
 $('#cnt').textContent=l.length+' stays found';$('#res').innerHTML=l.length?l.map(card).join(''):`<div class="empty"><h3>No hotels match</h3><p>Try widening your price range or removing filters.</p></div>`};
$('#fp').oninput=e=>{F.price=+e.target.value;$('#pv').textContent=fmt(F.price);draw()};$('#fr').onchange=e=>{F.rating=+e.target.value;draw()};$('#so').onchange=e=>{F.sort=e.target.value;draw()};
$$('[data-t]').forEach(x=>x.onchange=()=>{F.types=$$('[data-t]:checked').map(i=>i.dataset.t);draw()});$$('[data-a]').forEach(x=>x.onchange=()=>{F.amen=$$('[data-a]:checked').map(i=>i.dataset.a);draw()});
$('#fb').onchange=e=>{F.bf=e.target.checked;draw()};$('#ff').onchange=e=>{F.fc=e.target.checked;draw()};$('#rs').onclick=()=>{Object.assign(F,{price:10000,rating:0,types:[],amen:[],bf:false,fc:false,sort:'rec'});search()};draw()}

search();
