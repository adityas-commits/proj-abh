// Hotel data (sample). Images are generated gradients so the project works offline.
const GRADS=[['#0e7c7b','#17252a'],['#e8a33d','#9c3d54'],['#355c7d','#c06c84'],['#2d6a4f','#95d5b2'],['#6a4c93','#1982c4'],['#d1495b','#edae49']];
// Photo URLs (Unsplash hotlinks). If one fails to load, the gradient layer in bg() shows instead.
const photo=id=>`https://images.unsplash.com/photo-${id}?auto=format&fit=crop&w=900&q=70`;
const PH=['1566073771259-6a8506099945','1551882547-ff40c63fe5fa','1542314831-068cd1dbfeeb','1520250497591-112f2f40a3f4','1564501049412-61c2a3083791','1571896349842-33c89424de2d','1445019980597-93fa8acb246c','1582719508461-905c673771fd','1455587734955-081b22074882','1496417263034-38ec4f0b665a'];
const ROOMPH=['1611892440504-42a792e24d32','1590490360182-c33d57733427','1618773928121-c32242e63f39'];
const bg=(u,i=u.length)=>`url(${u}) center/cover,linear-gradient(135deg,${GRADS[i%6][0]},${GRADS[i%6][1]})`;
const mkRooms=(id,p)=>[
 {id:id+'-s',image:photo(ROOMPH[0]),name:'Standard Room',description:'Comfortable room with city views and work desk.',maxGuests:2,bedType:'1 Queen Bed',amenities:['WiFi','AC','TV'],price:p,breakfastIncluded:false,freeCancellation:false,available:5},
 {id:id+'-d',image:photo(ROOMPH[1]),name:'Deluxe Room',description:'Spacious room with premium bedding and seating area.',maxGuests:2,bedType:'1 King Bed',amenities:['WiFi','AC','Minibar'],price:Math.round(p*1.35/50)*50,breakfastIncluded:true,freeCancellation:true,available:4},
 {id:id+'-f',image:photo(ROOMPH[2]),name:'Family Suite',description:'Two-room suite ideal for families, with lounge.',maxGuests:4,bedType:'1 King + 2 Single Beds',amenities:['WiFi','AC','Bathtub','Lounge'],price:Math.round(p*2.1/50)*50,breakfastIncluded:true,freeCancellation:true,available:2}];
const H=(id,name,city,address,rating,rc,propertyType,distance,price,amen,desc,bf,fc,k)=>({id,name,city,address,images:[0,1,2,3].map(n=>photo(PH[(k+n)%PH.length])),rating,reviewCount:rc,description:desc,amenities:amen,roomTypes:mkRooms(id,price),price,propertyType,distance,cancellationPolicy:fc?'Free cancellation until 24 hours before check-in. Later cancellations refunded 50%.':'Non-refundable rate: 50% refund on cancellation.',breakfastAvailable:bf,freeCancel:fc});
const HOTELS=[
H('h1','The Marina Grand','Goa','Candolim Beach Rd, Goa',4.6,1820,'Resort','0.3 km from beach',4500,['Pool','WiFi','Spa','Parking','Restaurant'],'Beachfront resort with infinity pool, spa and sunset deck.',true,true,0),
H('h2','Palm Haven Villas','Goa','Anjuna, North Goa',4.3,640,'Villa','1.2 km from beach',3800,['Pool','WiFi','Parking','Kitchen'],'Private villas wrapped in coconut groves.',false,true,1),
H('h3','Gateway Residency','Mumbai','Colaba Causeway, Mumbai',4.2,2210,'Hotel','0.8 km from Gateway of India',5200,['WiFi','Gym','Restaurant','Parking'],'Classic city hotel near the harbour and cafés.',true,false,2),
H('h4','Skyline Suites','Mumbai','BKC, Mumbai',4.5,980,'Hotel','2 km from airport',7400,['WiFi','Gym','Pool','Spa','Restaurant'],'Business-ready suites with skyline views.',true,true,3),
H('h5','Lakeview Heritage','Udaipur','Lake Pichola Rd, Udaipur',4.8,1450,'Heritage','0.2 km from City Palace',6900,['WiFi','Pool','Spa','Restaurant'],'Restored haveli with lake-facing terraces.',true,true,4),
H('h6','Pink City Inn','Jaipur','MI Road, Jaipur',4.0,1130,'Hotel','1 km from Hawa Mahal',2600,['WiFi','Restaurant','Parking'],'Friendly budget stay in the heart of Jaipur.',false,false,5),
H('h7','Rampart Palace','Jaipur','Amer Road, Jaipur',4.7,870,'Heritage','3 km from Amer Fort',8800,['WiFi','Pool','Spa','Gym','Restaurant'],'Palace stay with courtyards and royal dining.',true,true,1),
H('h8','Backwater Bliss','Kochi','Fort Kochi, Kerala',4.4,760,'Resort','0.5 km from jetty',4100,['WiFi','Pool','Spa','Restaurant'],'Quiet resort on the backwaters with Ayurveda spa.',true,true,3),
H('h9','Tech Park Stay','Bengaluru','Whitefield, Bengaluru',3.9,1560,'Hotel','4 km from ITPL',3300,['WiFi','Gym','Parking'],'Practical rooms close to tech parks.',false,false,2),
H('h10','Garden Court','Bengaluru','Indiranagar, Bengaluru',4.4,1010,'Apartment','0.6 km from metro',3900,['WiFi','Kitchen','Gym','Parking'],'Serviced apartments in a leafy neighbourhood.',true,true,4)];
const CITIES=['Goa','Mumbai','Udaipur','Jaipur','Kochi','Bengaluru'];
const OFFERS=[['Early bird','Book 30 days ahead and enjoy lower rates.'],['Weekend escape','Stay Fri–Sun with breakfast included.'],['Long stay','Stay 5+ nights at selected hotels.']];
const DEST={Goa:photo('1512343879784-a960bf40e7f2'),Mumbai:photo('1529253355930-ddbe423a2ac7'),Udaipur:photo('1615836245337-f5b9b2303f10'),Jaipur:photo('1477587458883-47145ed94245'),Kochi:photo('1602216056096-3b40cc0c9944'),Bengaluru:photo('1596176530529-78163a4f7af2')};
