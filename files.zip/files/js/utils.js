const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const app=$('#app'),fmt=n=>'₹'+Math.round(n).toLocaleString('en-IN'),TAX=.18;
/* Shared helpers */
const today=()=>new Date().toISOString().slice(0,10);
const addDays=(d,n)=>{const x=new Date(d);x.setDate(x.getDate()+n);return x.toISOString().slice(0,10)};
const nightsBetween=(a,b)=>Math.round((new Date(b)-new Date(a))/864e5);
const fdate=d=>new Date(d).toLocaleDateString('en-IN',{day:'numeric',month:'short',year:'numeric'});
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
function toast(m,t='ok'){const e=document.createElement('div');e.className='toast '+t;e.textContent=m;$('#toasts').append(e);setTimeout(()=>e.remove(),3200)}
function modal(html){const m=$('#modal');m.innerHTML=`<div class="dialog">${html}</div>`;m.hidden=false}
const closeModal=()=>{$('#modal').hidden=true};
const hotel=id=>HOTELS.find(h=>h.id===id);
const crit=()=>LS.get('criteria')||{city:'',checkIn:addDays(today(),1),checkOut:addDays(today(),3),guests:2,rooms:1};
const stars=r=>`<span class="rate">★ ${r}</span>`;
const bstatus=b=>b.status==='Cancelled'?'Cancelled':(b.checkOut<today()?'Completed':'Upcoming');
function calc(price,rooms,nights){const sub=price*rooms*nights,tax=Math.round(sub*TAX);return{sub,tax,total:sub+tax}}
function card(h){return `<article class="card"><div class="ph" style="background:${bg(h.images[0])}"><span class="tag">${h.propertyType}</span></div><div class="cb"><div class="row"><h3>${h.name}</h3>${stars(h.rating)}</div><p class="mut">${h.city} · ${h.distance} · ${h.reviewCount} reviews</p><p class="chips">${h.amenities.slice(0,4).map(a=>`<i>${a}</i>`).join('')}</p><div class="row end"><div><small class="ok">${h.freeCancel?'Free cancellation':'Partial refund policy'}</small><br><b class="price">${fmt(h.price)}</b><small> / night + 18% taxes</small></div><a class="btn" href="hotel.html?id=${h.id}">View Rooms</a></div></div></article>`}

function ctx(){const s=LS.get('selection');if(!s)return null;const h=hotel(s.hotelId),r=h.roomTypes.find(x=>x.id===s.roomId),c=crit(),n=Math.max(1,nightsBetween(c.checkIn,c.checkOut));return{h,r,c,n,qty:s.qty,t:calc(r.price,s.qty,n)}}
const sumBox=x=>`<aside class="sticky box"><h3>Booking summary</h3><p><b>${x.h.name}</b><br><small class="mut">${x.h.city} · ${fdate(x.c.checkIn)} → ${fdate(x.c.checkOut)}</small></p><div class="line"><span>Room</span><span>${x.r.name}</span></div><div class="line"><span>Rooms</span><span>${x.qty}</span></div><div class="line"><span>Nights</span><span>${x.n}</span></div><div class="line"><span>Price / night</span><span>${fmt(x.r.price)}</span></div><div class="line"><span>Room subtotal</span><span>${fmt(x.t.sub)}</span></div><div class="line"><span>Taxes (18%)</span><span>${fmt(x.t.tax)}</span></div><div class="line tot"><span>Total</span><span>${fmt(x.t.total)}</span></div></aside>`;
const rowsOf=b=>[['Booking ID',b.id],['Hotel',b.hotelName],['Address',b.address],['Check-in',fdate(b.checkIn)],['Check-out',fdate(b.checkOut)],['Nights',b.nights],['Room',b.roomName],['Rooms',b.rooms],['Guests',b.guests],['Guest name',b.guest.fn+' '+b.guest.ln],['Total paid',fmt(b.total)],['Payment status',b.paymentStatus]];
const table=r=>`<div class="kv">${r.map(x=>`<div class="line"><span>${x[0]}</span><b>${esc(x[1])}</b></div>`).join('')}</div>`;
function invoice(b){$('#invoice').innerHTML=`<h1>Staywise – Tax Invoice</h1><p>Invoice for booking ${b.id} · ${fdate(b.createdAt)}</p>${table(rowsOf(b).slice(1,10))}<table><tr><td>Room subtotal</td><td>${fmt(b.subtotal)}</td></tr><tr><td>Taxes (18%)</td><td>${fmt(b.tax)}</td></tr><tr><td><b>Total</b></td><td><b>${fmt(b.total)}</b></td></tr></table><p>Demo document. Not a real invoice.</p>`;window.print()}
function cancelModal(id){const b=getBookingById(id);modal(`<h2>Are you sure you want to cancel this booking?</h2><div class="kv"><div class="line"><span>Original amount</span><b>${fmt(b.total)}</b></div><div class="line"><span>Refund amount</span><b class="ok">${fmt(refundFor(b))}</b></div></div><p class="mut">${b.policy}</p><div class="btns"><button class="btn ghost" id="k">KEEP BOOKING</button><button class="btn danger" id="y">CANCEL BOOKING</button></div>`);
$('#k').onclick=closeModal;$('#y').onclick=()=>{const r=cancelBooking(id);modal(`<div class="center"><div class="check">✓</div><h2>Booking cancelled</h2><p>${b.id} is cancelled. A refund of ${fmt(r.refund)} would be issued (simulated).</p><button class="btn" id="o">Done</button></div>`);$('#o').onclick=()=>{closeModal();location.pathname.endsWith('bookings.html')?bookings():location.href='bookings.html'};toast('Booking cancelled')}}
const notFound=()=>app.innerHTML='<div class="wrap sec"><div class="empty"><h2>Page not found</h2><p>That page or booking does not exist.</p><a class="btn" href="index.html">Go home</a></div></div>';
const noSel=()=>app.innerHTML='<div class="wrap sec"><div class="empty"><h2>No room selected</h2><p>Pick a hotel and room first.</p><a class="btn" href="search.html">Find hotels</a></div></div>';

$('#modal').onclick=e=>{if(e.target.id=='modal')closeModal()};
