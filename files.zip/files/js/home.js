/* ---------- HOME ---------- */
function home(){const c=crit();app.innerHTML=`<section class="hero"><div class="wrap"><h1>Find a stay that fits your trip</h1><p>Compare hotels, resorts and villas across India.</p>
<form id="sf" class="sform" novalidate><label>Destination<input id="city" list="cl" placeholder="City e.g. Goa" value="${esc(c.city)}"></label><datalist id="cl">${CITIES.map(x=>`<option>${x}</option>`).join('')}</datalist>
<label>Check-in<input type="date" id="ci" min="${today()}" value="${c.checkIn}"></label><label>Check-out<input type="date" id="co" value="${c.checkOut}"></label>
<label>Guests<input type="number" id="gu" min="1" max="12" value="${c.guests}"></label><label>Rooms<input type="number" id="ro" min="1" max="6" value="${c.rooms}"></label><button class="btn lg">Search</button></form></div></section>
<section class="wrap sec"><h2>Popular destinations</h2><div class="dest">${CITIES.map((x,i)=>`<a href="search.html" data-city="${x}" style="background:${bg(DEST[x])}"><b>${x}</b><small>${HOTELS.filter(h=>h.city===x).length} stays</small></a>`).join('')}</div></section>
<section class="wrap sec"><h2>Featured hotels</h2><div class="grid">${[...HOTELS].sort((a,b)=>b.rating-a.rating).slice(0,3).map(card).join('')}</div></section>
<section class="wrap sec"><h2>Special offers</h2><div class="grid">${OFFERS.map(o=>`<div class="offer"><h3>${o[0]}</h3><p>${o[1]}</p></div>`).join('')}</div></section>`;
$('#sf').onsubmit=e=>{e.preventDefault();const v={city:$('#city').value.trim(),checkIn:$('#ci').value,checkOut:$('#co').value,guests:+$('#gu').value,rooms:+$('#ro').value};
 const err=!v.city?'Destination is required':!v.checkIn?'Check-in is required':!v.checkOut?'Check-out is required':v.checkOut<=v.checkIn?'Check-out must be after check-in':v.guests<1?'Guests must be at least 1':v.rooms<1?'Rooms must be at least 1':v.checkIn<today()?'Check-in cannot be in the past':'';
 if(err)return toast(err,'err');LS.set('criteria',v);location.href='search.html'};
$$('[data-city]').forEach(a=>a.onclick=()=>LS.set('criteria',{...crit(),city:a.dataset.city}))}

home();
