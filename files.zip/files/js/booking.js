function guest(){const x=ctx();if(!x)return noSel();const g=LS.get('guest')||{};
app.innerHTML=`<div class="wrap sec"><h1>Guest details</h1><div class="split r"><form id="gf" class="box" novalidate>${[['fn','First name','text',g.fn],['ln','Last name','text',g.ln],['em','Email','email',g.em],['ph','Phone (10 digits)','tel',g.ph]].map(f=>`<label>${f[1]}<input id="${f[0]}" type="${f[2]}" value="${esc(f[3]||'')}"><small class="er" id="e-${f[0]}"></small></label>`).join('')}<label>Special requests (optional)<textarea id="sr" rows="3">${esc(g.sr||'')}</textarea></label><button class="btn lg">CONTINUE TO PAYMENT</button></form>${sumBox(x)}</div></div>`;
$('#gf').onsubmit=e=>{e.preventDefault();const v={fn:$('#fn').value.trim(),ln:$('#ln').value.trim(),em:$('#em').value.trim(),ph:$('#ph').value.trim(),sr:$('#sr').value.trim()};
 const er={fn:!v.fn&&'Required',ln:!v.ln&&'Required',em:!/^\S+@\S+\.\S+$/.test(v.em)&&'Enter a valid email',ph:!/^\d{10}$/.test(v.ph)&&'Enter a 10-digit phone number'};let bad=false;
 for(const k in er){$('#e-'+k).textContent=er[k]||'';if(er[k])bad=true}if(bad)return toast('Please fix the highlighted fields','err');LS.set('guest',v);location.href='payment.html'}}

guest();
