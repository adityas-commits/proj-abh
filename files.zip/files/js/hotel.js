/* ---------- HOTEL ---------- */
const REV=[['Aarav','Spotless rooms and very helpful staff.'],['Meera','Great location, would stay again.'],['Rohan','Breakfast spread was excellent.']];
function hotelPage(id){const h=hotel(id);if(!h)return notFound();const c=crit(),n=Math.max(1,nightsBetween(c.checkIn,c.checkOut));let sel={roomId:null,qty:0};
app.innerHTML=`<div class="wrap sec"><div class="gal">${h.images.map((g,i)=>`<div style="background:${bg(g)}" class="${i?'':'big'}"></div>`).join('')}</div>
<div class="split r"><div><h1>${h.name}</h1><p>${stars(h.rating)} <span class="mut">${h.reviewCount} reviews · ${h.address}</span></p><p>${h.description}</p><h3>Amenities</h3><p class="chips">${h.amenities.map(a=>`<i>${a}</i>`).join('')}</p>
<h3>Policies</h3><p>${h.cancellationPolicy}<br>Check-in 2 PM · Check-out 11 AM · Taxes 18%.</p><h3>Available rooms</h3><div id="rooms">${h.roomTypes.map(r=>`<div class="room" data-r="${r.id}"><div class="rp" style="background:${bg(r.image)}"></div><div class="rb"><h4>${r.name}</h4><p class="mut">${r.description}</p><p class="chips"><i>${r.maxGuests} Guests</i><i>${r.bedType}</i>${r.breakfastIncluded?'<i class="g">Breakfast Included</i>':''}${r.freeCancellation?'<i class="g">Free Cancellation</i>':''}${r.amenities.map(a=>`<i>${a}</i>`).join('')}</p>
<div class="row end"><div><b class="price">${fmt(r.price)}</b>/night<br><small class="mut">${r.available} left</small></div><div class="qty"><button data-d="-1" aria-label="Fewer">−</button><span>0</span><button data-d="1" aria-label="More">+</button></div></div></div></div>`).join('')}</div>
<h3>Reviews</h3>${REV.map(r=>`<p><b>${r[0]}</b> ★ ${h.rating}<br>${r[1]}</p>`).join('')}</div>
<aside class="sticky box"><h3>Your booking</h3><div id="bs"><p class="mut">Select a room to see your price.</p></div><button class="btn lg" id="go" disabled>CONTINUE TO BOOKING</button></aside></div></div>`;
const upd=()=>{$$('.room').forEach(e=>{const on=e.dataset.r===sel.roomId;e.classList.toggle('on',on);$('span',e).textContent=on?sel.qty:0});const r=h.roomTypes.find(x=>x.id===sel.roomId);
 if(!r||!sel.qty){$('#bs').innerHTML='<p class="mut">Select a room to see your price.</p>';$('#go').disabled=true;return}
 const t=calc(r.price,sel.qty,n);$('#go').disabled=false;$('#bs').innerHTML=`<p>${r.name} × ${sel.qty}<br><small class="mut">${fmt(r.price)} × ${n} night(s)</small></p><div class="line"><span>Subtotal</span><span>${fmt(t.sub)}</span></div><div class="line"><span>Taxes (18%)</span><span>${fmt(t.tax)}</span></div><div class="line tot"><span>Total</span><span>${fmt(t.total)}</span></div>`};
$$('.qty button').forEach(b=>b.onclick=()=>{const r=h.roomTypes.find(x=>x.id===b.closest('.room').dataset.r);if(sel.roomId!==r.id)sel={roomId:r.id,qty:0};const q=sel.qty+ +b.dataset.d;
 if(q>r.available)return toast(`Only ${r.available} ${r.name}(s) available`,'err');sel.qty=Math.max(0,q);upd()});
$('#go').onclick=()=>{const r=h.roomTypes.find(x=>x.id===sel.roomId);if(sel.qty*r.maxGuests<c.guests)return toast(`${sel.qty} room(s) fit only ${sel.qty*r.maxGuests} guests. Add rooms for ${c.guests} guests.`,'err');LS.set('selection',{hotelId:h.id,roomId:r.id,qty:sel.qty});location.href='booking.html'};upd()}

hotelPage(new URLSearchParams(location.search).get('id'));
