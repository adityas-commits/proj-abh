const LS={get:(k,d=null)=>{try{return JSON.parse(localStorage.getItem(k))??d}catch{return d}},set:(k,v)=>localStorage.setItem(k,JSON.stringify(v))};
const getBookings=()=>LS.get('bookings',[]);
const saveBooking=b=>{const a=getBookings();a.unshift(b);LS.set('bookings',a);return b};
const getBookingById=id=>getBookings().find(b=>b.id===id);
const updateBooking=(id,patch)=>{const a=getBookings().map(b=>b.id===id?{...b,...patch}:b);LS.set('bookings',a);return a.find(b=>b.id===id)};
const cancelBooking=id=>{const b=getBookingById(id);if(!b||b.status==='Cancelled')return null;return updateBooking(id,{status:'Cancelled',cancelledAt:new Date().toISOString(),refund:refundFor(b)})};
const refundFor=b=>b.freeCancel?b.total:Math.round(b.total*.5);
const genId=()=>{let id;do id='HTL-'+(100000+Math.floor(Math.random()*900000));while(getBookingById(id));return id};
